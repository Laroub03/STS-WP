<?php
/**
 * Class Google\Site_Kit\Modules\Search_Console
 *
 * @package   Google\Site_Kit
 * @copyright 2021 Google LLC
 * @license   https://www.apache.org/licenses/LICENSE-2.0 Apache License 2.0
 * @link      https://sitekit.withgoogle.com
 *
 * phpcs:disable PHPCS.Commenting.RequireDocTagDescription -- Pre-existing violations; tracked for follow-up cleanup.
 */

namespace Google\Site_Kit\Modules;

use Google\Site_Kit\Core\Assets\Asset;
use Google\Site_Kit\Core\Assets\Script;
use Google\Site_Kit\Core\Authentication\Clients\Google_Site_Kit_Client;
use Google\Site_Kit\Core\Modules\Module;
use Google\Site_Kit\Core\Modules\Module_Settings;
use Google\Site_Kit\Core\Modules\Module_With_Debug_Fields;
use Google\Site_Kit\Core\Modules\Module_With_Owner;
use Google\Site_Kit\Core\Modules\Module_With_Owner_Trait;
use Google\Site_Kit\Core\Modules\Module_With_Scopes;
use Google\Site_Kit\Core\Modules\Module_With_Scopes_Trait;
use Google\Site_Kit\Core\Modules\Module_With_Settings;
use Google\Site_Kit\Core\Modules\Module_With_Settings_Trait;
use Google\Site_Kit\Core\Modules\Module_With_Assets;
use Google\Site_Kit\Core\Modules\Module_With_Assets_Trait;
use Google\Site_Kit\Core\Modules\Module_With_Service_Entity;
use Google\Site_Kit\Core\Modules\Module_With_Data_Available_State;
use Google\Site_Kit\Core\Modules\Module_With_Data_Available_State_Trait;
use Google\Site_Kit\Core\Permissions\Permissions;
use Google\Site_Kit\Core\REST_API\Data_Request;
use Google\Site_Kit\Core\REST_API\Exception\Invalid_Datapoint_Exception;
use Google\Site_Kit\Core\Util\Date;
use Google\Site_Kit\Core\Util\Google_URL_Matcher_Trait;
use Google\Site_Kit\Core\Util\Google_URL_Normalizer;
use Google\Site_Kit\Core\Util\Sort;
use Google\Site_Kit\Modules\Search_Console\Settings;
use Google\Site_Kit\Modules\Search_Console\Datapoints\Batch_Search_Analytics;
use Google\Site_Kit\Modules\Search_Console\Datapoints\Get_Search_Analytics;
use Google\Site_Kit_Dependencies\Google\Service\Exception as Google_Service_Exception;
use Google\Site_Kit_Dependencies\Google\Service\SearchConsole as Google_Service_SearchConsole;
use Google\Site_Kit_Dependencies\Google\Service\SearchConsole\SitesListResponse as Google_Service_SearchConsole_SitesListResponse;
use Google\Site_Kit_Dependencies\Google\Service\SearchConsole\WmxSite as Google_Service_SearchConsole_WmxSite;
use Google\Site_Kit_Dependencies\Psr\Http\Message\ResponseInterface;
use Google\Site_Kit_Dependencies\Psr\Http\Message\RequestInterface;
use WP_Error;
use Exception;

/**
 * Class representing the Search Console module.
 *
 * @since 1.0.0
 * @access private
 * @ignore
 */
final class Search_Console extends Module implements Module_With_Scopes, Module_With_Settings, Module_With_Assets, Module_With_Debug_Fields, Module_With_Owner, Module_With_Service_Entity, Module_With_Data_Available_State {
	use Module_With_Scopes_Trait;
	use Module_With_Settings_Trait;
	use Google_URL_Matcher_Trait;
	use Module_With_Assets_Trait;
	use Module_With_Owner_Trait;
	use Module_With_Data_Available_State_Trait;

	/**
	 * Module slug name.
	 */
	const MODULE_SLUG = 'search-console';

	/**
	 * Registers functionality through WordPress hooks.
	 *
	 * @since 1.0.0
	 */
	public function register() {
		$this->register_scopes_hook();

		// Detect and store Search Console property when receiving token for the first time.
		add_action(
			'googlesitekit_authorize_user',
			function ( array $token_response ) {
				if ( ! current_user_can( Permissions::SETUP ) ) {
					return;
				}

				// If the response includes the Search Console property, set that.
				// But only if it is being set for the first time or if Search Console
				// has no owner or the current user is the owner.
				if ( ! empty( $token_response['search_console_property'] ) &&
				( empty( $this->get_property_id() ) || ( in_array( $this->get_owner_id(), array( 0, get_current_user_id() ), true ) ) ) ) {
					$this->get_settings()->merge(
						array( 'propertyID' => $token_response['search_console_property'] )
					);
					return;
				}

				// Otherwise try to detect if there isn't one set already.
				$property_id = $this->get_property_id() ?: $this->detect_property_id();
				if ( ! $property_id ) {
					return;
				}

				$this->get_settings()->merge(
					array( 'propertyID' => $property_id )
				);
			}
		);

		// Ensure that the data available state is reset when the property changes.
		$this->get_settings()->on_change(
			function ( $old_value, $new_value ) {
				if (
					is_array( $old_value ) &&
					is_array( $new_value ) &&
					isset( array_diff_assoc( $new_value, $old_value )['propertyID'] )
				) {
					$this->reset_data_available();
				}
			}
		);

		// Ensure that a Search Console property must be set at all times.
		add_filter(
			'googlesitekit_setup_complete',
			function ( $complete ) {
				if ( ! $complete ) {
					return $complete;
				}

				return (bool) $this->get_property_id();
			}
		);

		// Provide Search Console property information to JavaScript.
		add_filter(
			'googlesitekit_setup_data',
			function ( $data ) {
				$data['hasSearchConsoleProperty'] = (bool) $this->get_property_id();

				return $data;
			},
			11
		);
	}

	/**
	 * Gets required Google OAuth scopes for the module.
	 *
	 * @since 1.0.0
	 *
	 * @return array List of Google OAuth scopes.
	 */
	public function get_scopes() {
		return array(
			'https://www.googleapis.com/auth/webmasters', // The scope for the Search Console remains the legacy webmasters scope.
		);
	}

	/**
	 * Gets an array of debug field definitions.
	 *
	 * @since 1.5.0
	 *
	 * @return array
	 */
	public function get_debug_fields() {
		return array(
			'search_console_property' => array(
				'label' => __( 'Search Console: Property', 'google-site-kit' ),
				'value' => $this->get_property_id(),
			),
		);
	}

	/**
	 * Gets map of datapoint to definition data for each.
	 *
	 * @since 1.12.0
	 *
	 * @return array Map of datapoints to their definitions.
	 */
	protected function get_datapoint_definitions() {
		return array(
			'GET:matched-sites'          => array( 'service' => 'searchconsole' ),
			'GET:searchanalytics'        => $this->create_search_analytics_datapoint(),
			'POST:searchanalytics-batch' => new Batch_Search_Analytics(
				array(
					'service'   => function () {
						return $this->get_searchconsole_service();
					},
					'shareable' => true,
					'settings'  => $this->get_settings(),
					'context'   => $this->context,
				)
			),
			'POST:site'                  => array( 'service' => 'searchconsole' ),
			'GET:sites'                  => array( 'service' => 'searchconsole' ),
		);
	}

	/**
	 * Creates the search analytics datapoint.
	 *
	 * @since 1.186.0
	 *
	 * @return Get_Search_Analytics Search analytics datapoint instance.
	 */
	private function create_search_analytics_datapoint() {
		return new Get_Search_Analytics(
			array(
				'service'   => function () {
					return $this->get_searchconsole_service();
				},
				'shareable' => true,
				'settings'  => $this->get_settings(),
				'context'   => $this->context,
			)
		);
	}

	/**
	 * Creates a request object for the given datapoint.
	 *
	 * @since 1.0.0
	 *
	 * @param Data_Request $data Data request object.
	 * @return RequestInterface|callable|WP_Error Request object or callable on success, or WP_Error on failure.
	 *
	 * @throws Invalid_Datapoint_Exception Thrown if the datapoint does not exist.
	 */
	protected function create_data_request( Data_Request $data ) {
		switch ( "{$data->method}:{$data->datapoint}" ) {
			case 'GET:matched-sites':
				return $this->get_searchconsole_service()->sites->listSites();
			case 'POST:site':
				if ( empty( $data['siteURL'] ) ) {
					return new WP_Error(
						'missing_required_param',
						/* translators: %s: Missing parameter name */
						sprintf( __( 'Request parameter is empty: %s.', 'google-site-kit' ), 'siteURL' ),
						array( 'status' => 400 )
					);
				}

				$url_normalizer = new Google_URL_Normalizer();

				$site_url = $data['siteURL'];
				if ( 0 === strpos( $site_url, 'sc-domain:' ) ) { // Domain property.
					$site_url = 'sc-domain:' . $url_normalizer->normalize_url( str_replace( 'sc-domain:', '', $site_url, 1 ) );
				} else { // URL property.
					$site_url = $url_normalizer->normalize_url( trailingslashit( $site_url ) );
				}

				return function () use ( $site_url ) {
					$restore_defer = $this->with_client_defer( false );

					try {
						// If the site does not exist in the account, an exception will be thrown.
						$site = $this->get_searchconsole_service()->sites->get( $site_url );
					} catch ( Google_Service_Exception $exception ) {
						// If we got here, the site does not exist in the account, so we will add it.
						/* @var ResponseInterface $response Response object. */
						$response = $this->get_searchconsole_service()->sites->add( $site_url );

						if ( 204 !== $response->getStatusCode() ) {
							return new WP_Error(
								'failed_to_add_site_to_search_console',
								__( 'Error adding the site to Search Console.', 'google-site-kit' ),
								array( 'status' => 500 )
							);
						}

						// Fetch the site again now that it exists.
						$site = $this->get_searchconsole_service()->sites->get( $site_url );
					}

					$restore_defer();
					$this->get_settings()->merge( array( 'propertyID' => $site_url ) );

					return array(
						'siteURL'         => $site->getSiteUrl(),
						'permissionLevel' => $site->getPermissionLevel(),
					);
				};
			case 'GET:sites':
				return $this->get_searchconsole_service()->sites->listSites();
		}

		return parent::create_data_request( $data );
	}

	/**
	 * Parses a response for the given datapoint.
	 *
	 * @since 1.0.0
	 *
	 * @param Data_Request $data Data request object.
	 * @param mixed        $response Request response.
	 *
	 * @return mixed Parsed response data on success, or WP_Error on failure.
	 */
	protected function parse_data_response( Data_Request $data, $response ) {
		switch ( "{$data->method}:{$data->datapoint}" ) {
			case 'GET:matched-sites':
				/* @var Google_Service_SearchConsole_SitesListResponse $response Response object. */
				$entries     = Sort::case_insensitive_list_sort(
					$this->map_sites( (array) $response->getSiteEntry() ),
					'siteURL' // Must match the mapped value.
				);
				$strict      = filter_var( $data['strict'], FILTER_VALIDATE_BOOLEAN );
				$current_url = $this->context->get_reference_site_url();
				if ( ! $strict ) {
					$current_url = untrailingslashit( $current_url );
					$current_url = $this->strip_url_scheme( $current_url );
					$current_url = $this->strip_domain_www( $current_url );
				}

				$sufficient_permission_levels = array(
					'siteRestrictedUser',
					'siteOwner',
					'siteFullUser',
				);

				return array_values(
					array_filter(
						$entries,
						function ( array $entry ) use ( $current_url, $sufficient_permission_levels, $strict ) {
							if ( 0 === strpos( $entry['siteURL'], 'sc-domain:' ) ) {
								$match = $this->is_domain_match( substr( $entry['siteURL'], strlen( 'sc-domain:' ) ), $current_url );
							} else {
								$site_url = untrailingslashit( $entry['siteURL'] );
								if ( ! $strict ) {
									$site_url = $this->strip_url_scheme( $site_url );
									$site_url = $this->strip_domain_www( $site_url );
								}

								$match = $this->is_url_match( $site_url, $current_url );
							}
							return $match && in_array( $entry['permissionLevel'], $sufficient_permission_levels, true );
						}
					)
				);
			case 'GET:sites':
				/* @var Google_Service_SearchConsole_SitesListResponse $response Response object. */
				return $this->map_sites( (array) $response->getSiteEntry() );
		}

		return parent::parse_data_response( $data, $response );
	}

	/**
	 * Map Site model objects to associative arrays used for API responses.
	 *
	 * @param array $sites Site objects.
	 *
	 * @return array
	 */
	private function map_sites( $sites ) {
		return array_map(
			function ( Google_Service_SearchConsole_WmxSite $site ) {
				return array(
					'siteURL'         => $site->getSiteUrl(),
					'permissionLevel' => $site->getPermissionLevel(),
				);
			},
			$sites
		);
	}

	/**
	 * Gets the property ID.
	 *
	 * @since 1.3.0
	 *
	 * @return string Property ID URL if set, or empty string.
	 */
	protected function get_property_id() {
		$option = $this->get_settings()->get();

		return $option['propertyID'];
	}

	/**
	 * Detects the property ID to use for this site.
	 *
	 * This method runs a Search Console API request. The determined ID should therefore be stored and accessed through
	 * {@see Search_Console::get_property_id()} instead.
	 *
	 * @since 1.3.0
	 *
	 * @return string Property ID, or empty string if none found.
	 */
	protected function detect_property_id() {
		$properties = $this->get_data( 'matched-sites', array( 'strict' => 'yes' ) );
		if ( is_wp_error( $properties ) || ! $properties ) {
			return '';
		}

		// If there are multiple, prefer URL property over domain property.
		if ( count( $properties ) > 1 ) {
			$url_properties = array_filter(
				$properties,
				function ( $property ) {
					return 0 !== strpos( $property['siteURL'], 'sc-domain:' );
				}
			);
			if ( count( $url_properties ) > 0 ) {
				$properties = $url_properties;
			}
		}

		$property = array_shift( $properties );
		return $property['siteURL'];
	}

	/**
	 * Sets up information about the module.
	 *
	 * @since 1.0.0
	 *
	 * @return array Associative array of module info.
	 */
	protected function setup_info() {
		return array(
			'slug'        => 'search-console',
			'name'        => _x( 'Search Console', 'Service name', 'google-site-kit' ),
			'description' => __( 'Google Search Console and helps you understand how Google views your site and optimize its performance in search results.', 'google-site-kit' ),
			'order'       => 1,
			'homepage'    => __( 'https://search.google.com/search-console', 'google-site-kit' ),
		);
	}

	/**
	 * Get the configured SearchConsole service instance.
	 *
	 * @since 1.25.0
	 *
	 * @return Google_Service_SearchConsole The Search Console API service.
	 */
	private function get_searchconsole_service() {
		return $this->get_service( 'searchconsole' );
	}

	/**
	 * Sets up the Google services the module should use.
	 *
	 * This method is invoked once by {@see Module::get_service()} to lazily set up the services when one is requested
	 * for the first time.
	 *
	 * @since 1.0.0
	 * @since 1.2.0 Now requires Google_Site_Kit_Client instance.
	 *
	 * @param Google_Site_Kit_Client $client Google client instance.
	 * @return array Google services as $identifier => $service_instance pairs. Every $service_instance must be an
	 *               instance of Google_Service.
	 */
	protected function setup_services( Google_Site_Kit_Client $client ) {
		return array(
			'searchconsole' => new Google_Service_SearchConsole( $client ),
		);
	}

	/**
	 * Sets up the module's settings instance.
	 *
	 * @since 1.3.0
	 *
	 * @return Module_Settings
	 */
	protected function setup_settings() {
		return new Settings( $this->options );
	}

	/**
	 * Sets up the module's assets to register.
	 *
	 * @since 1.9.0
	 *
	 * @return Asset[] List of Asset objects.
	 */
	protected function setup_assets() {
		$base_url = $this->context->url( 'dist/assets/' );

		return array(
			new Script(
				'googlesitekit-modules-search-console',
				array(
					'src'          => $base_url . 'js/googlesitekit-modules-search-console.js',
					'dependencies' => array(
						'googlesitekit-vendor',
						'googlesitekit-api',
						'googlesitekit-data',
						'googlesitekit-datastore-user',
						'googlesitekit-modules',
						'googlesitekit-components',
						'googlesitekit-modules-data',
					),
				)
			),
		);
	}

	/**
	 * Returns TRUE to indicate that this module should be always active.
	 *
	 * @since 1.49.0
	 *
	 * @return bool Returns `true` indicating that this module should be activated all the time.
	 */
	public static function is_force_active() {
		return true;
	}

	/**
	 * Checks if the current user has access to the current configured service entity.
	 *
	 * @since 1.70.0
	 *
	 * @return boolean|WP_Error
	 */
	public function check_service_entity_access() {
		$data_request = new Data_Request(
			'GET',
			'modules',
			self::MODULE_SLUG,
			'searchanalytics',
			array(
				'startDate' => gmdate( 'Y-m-d', Date::now() ),
				'endDate'   => gmdate( 'Y-m-d', Date::now() ),
				'limit'     => 1,
			)
		);

		try {
			$this->create_search_analytics_datapoint()->create_request( $data_request );
		} catch ( Exception $e ) {
			if ( $e->getCode() === 403 ) {
				return false;
			}
			return $this->exception_to_error( $e );
		}

		return true;
	}
}

<?php
/**
 * Class Google\Site_Kit\Core\User\REST_Email_Reporting_Controller
 *
 * @package   Google\Site_Kit\Core\User
 * @copyright 2025 Google LLC
 * @license   https://www.apache.org/licenses/LICENSE-2.0 Apache License 2.0
 * @link      https://sitekit.withgoogle.com
 */

namespace Google\Site_Kit\Core\User;

use Google\Site_Kit\Core\Email_Reporting\Email_Reporting_Scheduler;
use Google\Site_Kit\Core\Permissions\Permissions;
use Google\Site_Kit\Core\REST_API\REST_Route;
use Google\Site_Kit\Core\REST_API\REST_Routes;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * Class for handling email reporting user settings via REST API.
 *
 * @since 1.162.0
 * @access private
 * @ignore
 */
class REST_Email_Reporting_Controller {

	/**
	 * Email_Reporting_Settings instance.
	 *
	 * @since 1.162.0
	 * @var Email_Reporting_Settings
	 */
	private $settings;

	/**
	 * Email reporting scheduler instance.
	 *
	 * @since 1.174.0
	 * @var Email_Reporting_Scheduler
	 */
	private $scheduler;

	/**
	 * Constructor.
	 *
	 * @since 1.162.0
	 *
	 * @param Email_Reporting_Settings  $settings  Email_Reporting_Settings instance.
	 * @param Email_Reporting_Scheduler $scheduler Scheduler instance.
	 */
	public function __construct( Email_Reporting_Settings $settings, Email_Reporting_Scheduler $scheduler ) {
		$this->settings  = $settings;
		$this->scheduler = $scheduler;
	}

	/**
	 * Registers functionality through WordPress hooks.
	 *
	 * @since 1.162.0
	 */
	public function register() {
		add_filter(
			'googlesitekit_rest_routes',
			function ( $routes ) {
				return array_merge( $routes, $this->get_rest_routes() );
			}
		);

		add_filter(
			'googlesitekit_apifetch_preload_paths',
			function ( $paths ) {
				return array_merge(
					$paths,
					array(
						'/' . REST_Routes::REST_ROOT . '/core/user/data/email-reporting-settings',
						'/' . REST_Routes::REST_ROOT . '/core/user/data/email-reporting-next-report',
					)
				);
			}
		);
	}

	/**
	 * Gets REST route instances.
	 *
	 * @since 1.162.0
	 * @since 1.185.0 Added the `email-reporting-next-report` route.
	 *
	 * @return REST_Route[] List of REST_Route objects.
	 */
	protected function get_rest_routes() {
		$can_view_dashboard = function () {
			return current_user_can( Permissions::VIEW_DASHBOARD );
		};

		return array(
			new REST_Route(
				'core/user/data/email-reporting-settings',
				array(
					array(
						'methods'             => WP_REST_Server::READABLE,
						'callback'            => function () {
							return new WP_REST_Response( $this->settings->get() );
						},
						'permission_callback' => $can_view_dashboard,
					),
					array(
						'methods'             => WP_REST_Server::EDITABLE,
						'callback'            => function ( WP_REST_Request $request ) {
							$previous_settings = $this->settings->get();
							$settings = $request['data']['settings'];

							$this->settings->merge( $settings );

							$updated_settings = $this->settings->get();

							$scheduling_error = $this->scheduler->schedule_email_confirmation(
								get_current_user_id(),
								$previous_settings,
								$updated_settings
							);

							if ( is_wp_error( $scheduling_error ) ) {
								return $scheduling_error;
							}

							return new WP_REST_Response( $updated_settings );
						},
						'permission_callback' => $can_view_dashboard,
						'args'                => array(
							'data' => array(
								'type'       => 'object',
								'required'   => true,
								'properties' => array(
									'settings' => array(
										'type'          => 'object',
										'required'      => true,
										'minProperties' => 1,
										'additionalProperties' => false,
										'properties'    => array(
											'frequency'  => array(
												'type' => 'string',
												'enum' => array(
													Email_Reporting_Settings::FREQUENCY_WEEKLY,
													Email_Reporting_Settings::FREQUENCY_MONTHLY,
													Email_Reporting_Settings::FREQUENCY_QUARTERLY,
												),
											),
											'subscribed' => array(
												'type' => 'boolean',
											),
										),
									),
								),
							),
						),
					),
				)
			),
			new REST_Route(
				'core/user/data/email-reporting-next-report',
				array(
					array(
						'methods'             => WP_REST_Server::READABLE,
						'callback'            => function () {
							$frequency = $this->settings->get()['frequency'];
							$timestamp = $this->scheduler->get_next_report_timestamp( $frequency );

							return new WP_REST_Response( array( 'timestamp' => $timestamp ) );
						},
						'permission_callback' => $can_view_dashboard,
					),
				)
			),
		);
	}
}

<?php
/**
 * Class Google\Site_Kit\Core\Authentication\Guards\Using_Proxy_Connection_Guard
 *
 * @package   Google\Site_Kit
 * @copyright 2024 Google LLC
 * @license   https://www.apache.org/licenses/LICENSE-2.0 Apache License 2.0
 * @link      https://sitekit.withgoogle.com
 *
 * phpcs:disable PHPCS.Commenting.RequireDocTagDescription -- Pre-existing violations; tracked for follow-up cleanup.
 */

namespace Google\Site_Kit\Core\Authentication\Guards;

use Google\Site_Kit\Core\Authentication\Credentials;
use Google\Site_Kit\Core\Guards\Guard_Interface;

/**
 * Class providing guard logic based on proxy connection.
 *
 * @since 1.133.0
 * @access private
 * @ignore
 */
class Using_Proxy_Connection_Guard implements Guard_Interface {

	/**
	 * Credentials instance.
	 *
	 * @var Credentials
	 */
	private Credentials $credentials;

	/**
	 * Constructor.
	 *
	 * @since 1.133.0
	 * @param Credentials $credentials Credentials instance.
	 */
	public function __construct( Credentials $credentials ) {
		$this->credentials = $credentials;
	}

	/**
	 * Determines whether the guarded entity can be activated or not.
	 *
	 * @since 1.133.0
	 * @return bool|\WP_Error
	 */
	public function can_activate() {
		return $this->credentials->using_proxy();
	}
}
